package com.example.abc.setting;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //@Override

    EditText EditTextPwdOld;
    EditText EditTextPwdNew;
    EditText EditTextPwdCh;
    EditText EditTextPwdOg;
    Button buttonPwd;
    Button buttonSign;
    EditText EditTextSignDay;




    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //findViews();
        //Button button=(Button)findViewById(R.id.button_1);
        buttonPwd=(Button)findViewById(R.id.buttonPwd);
        EditTextPwdOld=(EditText)findViewById(R.id.editTextPwdOld);
        EditTextPwdNew=(EditText)findViewById(R.id.editTextPwdNew);
        EditTextPwdCh=(EditText)findViewById(R.id.editTextPwdCh);
        EditTextPwdOg=(EditText)findViewById(R.id.editTextPwdOg);

        buttonSign=(Button)findViewById(R.id.buttonSign);
        EditTextSignDay=(EditText)findViewById(R.id.editTextSignDay);


        buttonSign.setOnClickListener(new OnClickListener() {
            //@Override
            public void onClick(View v) {
                //int signedDay=EditTextSignDay.getText();
                int signedDay=Integer.parseInt(EditTextSignDay.getText().toString());
                signedDay=signedDay+1;
                //EditTextSignDay.setText(signedDay);
                EditTextSignDay.setText(String.valueOf(signedDay));
                Toast.makeText(MainActivity.this, "签到成功!", Toast.LENGTH_SHORT).show();
            }
        });


        buttonPwd.setOnClickListener(new OnClickListener() {
            //@Override
            public void onClick(View v) {
                String PwdOld=EditTextPwdOld.getText().toString();
                String PwdNew=EditTextPwdNew.getText().toString();
                String PwdCh=EditTextPwdCh.getText().toString();
                String PwdOg=EditTextPwdOg.getText().toString();
                boolean ExeChange=true;
                //Toast.makeText(MainActivity.this, "click!", Toast.LENGTH_SHORT).show();
                //Toast.makeText(MainActivity.this, PwdCh, Toast.LENGTH_SHORT).show();
                if(ExeChange)
                {

                }
                if(ExeChange)
                {
                    if (PwdOld.equals(PwdOg)==false)
                    {
                        ExeChange=false;
                        Toast.makeText(MainActivity.this, "原始密码错误,请重新输入!", Toast.LENGTH_SHORT).show();
                    }
                }
                if(ExeChange)
                {
                    if(PwdNew.equals(""))
                    {
                        ExeChange=false;
                        Toast.makeText(MainActivity.this, "新密码不能为空,请重新输入!", Toast.LENGTH_SHORT).show();
                    }
                }
                if(ExeChange)
                {
                    if(PwdNew.equals(PwdCh)==false)
                    {
                        ExeChange=false;
                        Toast.makeText(MainActivity.this, "新密码必须与确认密码一致,请重新输入!", Toast.LENGTH_SHORT).show();
                    }
                }
                if(ExeChange)
                {
                    if(PwdNew.equals(PwdOld))
                    {
                        ExeChange=false;
                        Toast.makeText(MainActivity.this, "新密码不能与原密码相同,请重新输入!", Toast.LENGTH_SHORT).show();
                    }
                }
                if (ExeChange)
                {
                    PwdOg=PwdNew;
                    EditTextPwdOg.setText(PwdOg);
                    Toast.makeText(MainActivity.this, "密码修改成功!", Toast.LENGTH_SHORT).show();
                }


/*                if(PwdCh.equals(PwdNew))
                {
                    //buttonPwd.setText("right!");
                    //Toast.makeText(MainActivity.this, "You click Button 1", Toast.LENGTH_SHORT).show();
                    Toast.makeText(MainActivity.this, "right from bayleef!", Toast.LENGTH_SHORT).show();
                }
*/
            }
        });
    }
}






/*public class RegisterActivity extends Activity {
    EditText username;
    EditText password;
    EditText age;
    RadioGroup sex;
    Button register;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        findViews();
        register.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                String name=username.getText().toString().trim();
                String pass=password.getText().toString().trim();
                String agestr=age.getText().toString().trim();
                String sexstr=((RadioButton)RegisterActivity.this.findViewById(sex.getCheckedRadioButtonId())).getText().toString();
                Log.i("TAG",name+"_"+pass+"_"+agestr+"_"+sexstr);
                UserService uService=new UserService(RegisterActivity.this);
                User user=new User();
                user.setUsername(name);
                user.setPassword(pass);
                user.setAge(Integer.parseInt(agestr));
                user.setSex(sexstr);
                uService.register(user);
                Toast.makeText(RegisterActivity.this, "注册成功", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        });
    }
    private void findViews() {
        username=(EditText) findViewById(R.id.usernameRegister);
        password=(EditText) findViewById(R.id.passwordRegister);
        age=(EditText) findViewById(R.id.ageRegister);
        sex=(RadioGroup) findViewById(R.id.sexRegister);
        register=(Button) findViewById(R.id.Register);
    }

}
*/